// import React from 'react';
// import { Route, IndexRoute, Router, browserHistory } from 'react-router';
//
// import BarIndexContainer from './containers/BarIndexContainer'
// import ReviewIndexContainer from './containers/ReviewIndexContainer'
// import BarShowContainer from './containers/BarShowContainer'
//
// const App = (props) => {
//   return (
//     <Router history={browserHistory}>
//       <Route path = '/bars' component={BarIndexContainer}/>
//       <Route path = '/reviews' component={ReviewIndexContainer}/>
//       <Route path = '/bars/:id' component={BarShowContainer}/>
//     </Router>
//   )
// }
//
// export default AppRouter;
